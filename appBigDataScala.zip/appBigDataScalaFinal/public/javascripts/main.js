function Centro(lat, lng){
	this.lat = lat;
	this.lng = lng;
}

function Bairro(centro, nome, incidencias, pesoPonderado){
	this.centro = centro;
	this.incidencias = incidencias;
	this.nome = nome;
	this.pesoPonderado = pesoPonderado;
}

var bairroMap = criarArrayGoogleChart(JSON.parse($('#dadosInicio').val())); 
	  
//alert(array);
call_google_charts();		

google.charts.load("current", {packages:['corechart']});
google.charts.setOnLoadCallback(drawChart);

function criarArrayGoogleChart(origem){
	var combinado = new Array();
	combinado[0] = ['centro', 'Local', 'Incidencias', 'PesoComparado'];
	for (var i = 0; i < origem.length; i++){
	  combinado[i+1] = new Bairro(new Centro(origem[i]["Lat"], origem[i]["Long"]), origem[i]["Local"], origem[i]["Incidencias"], origem[i]["PesoComparado"]);
	  
	}	
	return combinado;
}

function criarArrayDataColumns(bairroMap){
	var combinado = new Array();
	combinado[0] = ["Bairro", "Incidencia", { role: "style" }];
	for (var i = 1; i < bairroMap.length; i++){
	  combinado[i] = [ bairroMap[i].nome, bairroMap[i].incidencias, "red" ];
	}	
	return combinado;
}
		
$('#filtro').change(function(e) {	
    return callAjax();
});

$('#marca').change(function(e) {	
    return callAjax();
});

function callAjax(){
    var idToGet = $("#filtro option:selected").val();	
    var marca = $("#marca option:selected").val();
    $.ajax({
        type : 'GET',
        url : jsRoutes.controllers.Application.ajaxCall(idToGet, marca).url,
        success : function(data) {			
			bairroMap = criarArrayGoogleChart(data);
            //alert(bairroMap);
			call_google_charts();
			drawChart();
			$("#mydiv").load(location.href + " #mydiv");
        }
    });	
	//alert(idToGet);
    return false;
}

function call_google_charts(){
	
	var map = new google.maps.Map($('#map_div')[0], {
		  zoom: 11,
          center: {lat: -22.938476, lng: -43.435010},
          mapTypeId: 'roadmap'
        });
    
	var url = 'https://icons.iconarchive.com/icons/icons-land/vista-map-markers/48/Map-Marker-Ball-Pink-icon.png';
		  
        // Construct the circle for each value in citymap.
        // Note: We scale the area of the circle based on the population.
        for (var bairro in bairroMap) {
          // Add the circle for this city to the map.
          var bairroCirculo = new google.maps.Circle({
            strokeColor: '#FF0000',
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: '#FF0000',
            fillOpacity: 0.35,
            map: map,
            center: bairroMap[bairro].centro,
            radius: bairroMap[bairro].pesoPonderado *10 //Math.sqrt(bairroMap[bairro].population) * 100
          });
		  		  
		  var marker = new google.maps.Marker({
				position: bairroMap[bairro].centro,
				title: bairroMap[bairro].nome + ": " + bairroMap[bairro].incidencias,
				icon: url
		  });

		  // To add the marker to the map, call setMap();
		  marker.setMap(map);
        }
		
}	  


function drawChart() {
	var arrayDataColumns = criarArrayDataColumns(bairroMap);
   	var dataColumns = google.visualization.arrayToDataTable(arrayDataColumns);
	
	var view = new google.visualization.DataView(dataColumns);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Incidencias de Roubos de carros no Rio de Janeiro",
        width: 960,
        height: 330,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart($('#chart_div')[0]);
      chart.draw(view, options);
  }	

